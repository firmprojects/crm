from django.shortcuts import render
from django.views.generic import ListView, DetailView, View, TemplateView, CreateView, UpdateView


class Estimates(TemplateView):
    template_name = 'accounts/estimates.html'

class CreateEstimates(TemplateView):
    template_name = 'accounts/create_estimates.html'


class EstimatesView(TemplateView):
    template_name = 'accounts/estimates_view.html'


class EstimatesEdit(TemplateView):
    template_name = 'accounts/estimates_edit.html'


class Invoice(TemplateView):
    template_name = 'accounts/invoice.html'

class CreateInvoice(TemplateView):
    template_name = 'accounts/create_invoice.html'

class InvoiceView(TemplateView):
    template_name = 'accounts/invoice_view.html'


class InvoiceEdit(TemplateView):
    template_name = 'accounts/invoice_edit.html'


class Payment(TemplateView):
    template_name = 'accounts/payment.html'

class Expenses(TemplateView):
    template_name='accounts/expenses.html'

class ProvidentFund(TemplateView):
    template_name='accounts/provident.html'

class Taxes(TemplateView):
    template_name='accounts/taxes.html'

class Salary(TemplateView):
    template_name='accounts/salary.html'


class PaySlip(TemplateView):
    template_name='accounts/pay_slip.html'


class ClientProfile(TemplateView):
    template_name='accounts/client_profile.html'

class EditProfile(TemplateView):
    template_name='accounts/edit_profile.html'


class ExpenseReport(TemplateView):
    template_name = 'accounts/expense_report.html'

class InvoiceReport(TemplateView):
    template_name = 'accounts/invoice_report.html'


