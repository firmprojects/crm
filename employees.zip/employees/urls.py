from django.contrib import admin
from django.urls import path
from employees.views import EmployeesList, Holidays, Leaves, Attendants, Designation, Departments

app_name = 'employees'
urlpatterns = [
    path('', EmployeesList.as_view(), name="employees_list"),
    path('holidays', Holidays.as_view(), name="holidays"),
    path('leaves', Leaves.as_view(), name="leaves"),
    path('attendants', Attendants.as_view(), name="attendants"),
    path('departments', Departments.as_view(), name="departments"),
    path('designation', Designation.as_view(), name="designation"),
]