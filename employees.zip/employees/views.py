from django.shortcuts import render
from django.views.generic import ListView, DetailView, View, TemplateView, CreateView, UpdateView

class EmployeesList(TemplateView):
    template_name = 'employees/employees_list.html'

class Holidays(TemplateView):
    template_name = 'employees/holidays.html'


class Leaves(TemplateView):
    template_name = 'employees/leaves.html'

class Attendants(TemplateView):
    template_name = 'employees/attendants.html'

class Departments(TemplateView):
    template_name = 'employees/departments.html'

class Designation(TemplateView):
    template_name = 'employees/designation.html'