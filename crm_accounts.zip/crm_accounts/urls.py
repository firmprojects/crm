from django.contrib import admin
from django.urls import path
from .views import (
    Estimates, 
    CreateEstimates, 
    EstimatesView, 
    EstimatesEdit,
    Invoice,
    CreateInvoice,
    InvoiceView,
    InvoiceEdit,
    Payment,
    Expenses,
    ProvidentFund,
    Taxes,
    Salary,
    PaySlip,
    EditProfile,
    ExpenseReport,
    InvoiceReport
    )

app_name = 'accounts'
urlpatterns = [
    path('estimates', Estimates.as_view(), name="estimates"),
    path('create/estimate', CreateEstimates.as_view(), name="create_estimates"),
    path('estimate/view', EstimatesView.as_view(), name="estimates_view"),
    path('estimate/edit', EstimatesEdit.as_view(), name="estimates_edit"),
    path('invoice', Invoice.as_view(), name="invoice"),
    path('create/invoice', CreateInvoice.as_view(), name="create_invoice"),
    path('invoice/view', InvoiceView.as_view(), name="invoice_view"),
    path('invoice/edit', InvoiceEdit.as_view(), name="invoice_edit"),
    path('payment', Payment.as_view(), name="payment"),
    path('expenses', Expenses.as_view(), name="expenses"),
    path('provident', ProvidentFund.as_view(), name="provident"),
    path('taxes', Taxes.as_view(), name="taxes"),
    path('salary', Salary.as_view(), name="salary"),
    path('pay_slip', PaySlip.as_view(), name="pay_slip"),
    path('edit_profile', EditProfile.as_view(), name="edit_profile"),
    path('expense-report', ExpenseReport.as_view(), name="expense_report"),
    path('invoice-report', InvoiceReport.as_view(), name="invoice_report"),
]