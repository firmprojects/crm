from django.shortcuts import render
from django.views.generic import ListView, DetailView, View, TemplateView, CreateView, UpdateView

class Project(TemplateView):
    template_name = 'project/project.html'


class ProjectView(TemplateView):
    template_name = 'project/project-view.html'


class ProjectList(TemplateView):
    template_name = 'project/project-list.html'


class Task(TemplateView):
    template_name = 'project/task.html'


class Lead(TemplateView):
    template_name = 'project/lead.html'



class Clients(TemplateView):
    template_name='project/client.html'


class ClientProfile(TemplateView):
    template_name='project/client_profile.html'
    

class ClientList(TemplateView):
    template_name='project/client_list.html'


class Ticket(TemplateView):
    template_name='project/ticket.html'


class TicketView(TemplateView):
    template_name='project/ticket_view.html'

class TimeSheet(TemplateView):
    template_name='project/timesheet.html'


