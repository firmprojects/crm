from django.contrib import admin
from django.urls import path
from .views import (
    Project, 
    ProjectView, 
    ProjectList, 
    ClientProfile, 
    Clients, 
    ClientList, 
    Task, 
    Lead,
    Ticket,
    TicketView,
    TimeSheet 
    )

app_name = 'project'
urlpatterns = [
    path('project', Project.as_view(), name='project'),
    path('project-view', ProjectView.as_view(), name='project-view'),
    path('project-list', ProjectList.as_view(), name='project-list'),
    path('task', Task.as_view(), name="task"),
     path('lead', Lead.as_view(), name="lead"),
    path('clients', Clients.as_view(), name="clients"),
    path('clients-list', ClientList.as_view(), name="clients-list"),
    path('client_profile', ClientProfile.as_view(), name="client_profile"),
    path('ticket', Ticket.as_view(), name="ticket"),
    path('ticket-view', TicketView.as_view(), name="ticket_view"),
    path('timesheet', TimeSheet.as_view(), name="timesheet"),
    ]