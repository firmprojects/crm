from django.contrib import admin
from .models import Ticketing

admin.site.register(Ticketing)
